// BEP-20 addresses.
export const CAKE = "0xdBF2d59f590eD72e647d1ea1E99417995B9C9368";
export const SYRUP = "0x009cF7bC57584b7998236eff51b98A168DceA9B0";

// Contract addresses.
export const LOTTERY_CONTRACT = "0x970658f76ea349f014AF01aE2b9b22DF4ca9281a";
